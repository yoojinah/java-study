package com.myuniversity.students;

public class GraduatrStudent {
}
