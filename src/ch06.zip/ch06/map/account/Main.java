package ch06.map.account;

public class Main {
    public static void main(String[] args) {
        AccountManagement accountManagement = new AccountManagement();
        accountManagement.run();

    }
}
