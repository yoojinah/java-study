package ch06.list.account;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        AccountManagement accountManagement = new AccountManagement();
        accountManagement.run();

    }
}
